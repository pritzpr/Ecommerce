from django.urls import path
from . import views

urlpatterns = [
    path("customer/signup/", views.customersignup.as_view()),
    path("customer/login/", views.customerlogin.as_view()),
    path("customer/profile/<username>/", views.customerprofile.as_view()),
    path("profile/update/", views.updateprofile.as_view()),
    path("profile/delete/<username>/", views.deleteprofile.as_view()),
    path("product/specific/<p_id>/", views.getspecificproduct.as_view()),
]
