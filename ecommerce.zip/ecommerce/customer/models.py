from django.db import models

# Create your models here.
class customerData(models.Model):
    username = models.CharField(max_length=10,primary_key=True)
    email = models.EmailField(unique=True)
    mobile = models.IntegerField(unique=True)
    password = models.CharField(max_length=100)

class profile(models.Model):
    username = models.ForeignKey(customerData, on_delete=models.CASCADE)
    email = models.EmailField(unique=True)
    mobile = models.IntegerField(unique=True)
    password = models.CharField(max_length=100)
    first_name = models.CharField(max_length= 50 , null=True,blank=True)
    last_name = models.CharField(max_length=50, null=True, blank=True)
    gender = models.CharField(max_length=10, null=True, blank=True)

class product(models.Model):
    p_id = models.CharField(max_length=10, primary_key=True)
    p_name = models.CharField(max_length=100)
    price = models.IntegerField()
    d_price = models.IntegerField(null=True, blank=True)
    exp_date = models.DateField()

class category(models.Model):
    p_id = models.ForeignKey(product,on_delete=models.CASCADE)
    c_name = models.CharField(max_length=100, primary_key=True)

class sub_category(models.Model):
    c_name = models.ForeignKey(category,on_delete=models.CASCADE)
    sub_c_name = models.CharField(max_length=100, primary_key=True)
