from rest_framework import serializers

class customersignupserializer(serializers.Serializer):
    username = serializers.CharField(max_length=10)
    email = serializers.EmailField()
    mobile = serializers.IntegerField()
    password = serializers.CharField(max_length=100)

class customerloginserializer(serializers.Serializer):
    username = serializers.CharField(max_length=10)
    password = serializers.CharField(max_length=100)

class updateprofileserializer(serializers.Serializer):
    username = serializers.CharField(max_length=10, required=False)
    first_name = serializers.CharField(max_length=50, required=False)
    last_name = serializers.CharField(max_length=50, required=False)
    gender = serializers.CharField(max_length=10, required=False)