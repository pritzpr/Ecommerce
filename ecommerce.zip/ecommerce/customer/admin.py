from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(customerData)
admin.site.register(profile)
admin.site.register(product)
admin.site.register(category)
admin.site.register(sub_category)