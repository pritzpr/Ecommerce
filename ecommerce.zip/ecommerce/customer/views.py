from rest_framework.views import APIView
from rest_framework import status
from django.http import JsonResponse
from .serializers import *
from .models import *

class customersignup(APIView):
    def post(self, request):
        try:
            serializer = customersignupserializer(data=request.data)
            if serializer.is_valid():
                username = serializer.data["username"]
                email = serializer.data["email"]
                mobile = serializer.data["mobile"]
                password = serializer.data["password"]

                customerData.objects.create(
                    username = username,
                    email = email,
                    mobile = mobile,
                    password = password
                )

                profile.objects.create(
                    username_id=username,
                    email=email,
                    mobile=mobile,
                    password=password
                )

                message = {"message":"Customer Signup Successful"}
                return JsonResponse(message,status = status.HTTP_201_CREATED, safe=False)
            else:
                return JsonResponse(message,status = status.HTTP_400_BAD_REQUEST, safe=False)
        except Exception as e:
            message = {"Error":str(e)}
            return JsonResponse(message,status = status.HTTP_400_BAD_REQUEST, safe=False)

class customerlogin(APIView):
    def post(self,request):
        try:
            serializer = customerloginserializer(data=request.data)
            if serializer.is_valid():
                username = serializer.data["username"]
                password = serializer.data["password"]

                #query to login

                logindata = list(customerData.objects.filter(
                    username = username,
                    password = password
                ).values())

                if len(logindata) == 1:
                    message = {"message" : "Login Successfully"}
                    return JsonResponse(message,status = status.HTTP_200_OK, safe=False)

                else:
                    message = {"message" : "Invalid Credentials"}
                    return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)
            else:
                return JsonResponse(serializer.errors, status=status.HTTP_200_OK, safe=False)

        except Exception as e:
            message = {"Error": str(e)}
            return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)


class customerprofile(APIView):
    def get(self,request,username):
        try:
            profiledata = list(profile.objects.filter(
                username_id = username
            ).values())
            return JsonResponse(profiledata, status=status.HTTP_200_OK, safe=False)

        except Exception as e:
            message = {"Error": str(e)}
            return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)


class updateprofile(APIView):
    def put(self, request):
        try:
            serializer = updateprofileserializer(data=request.data)
            if serializer.is_valid():
                username = serializer.data["username"]
                profile.objects.filter(username=username).update(
                    **serializer.data
                )
                message={"message":"Profile updated successfully"}
                return JsonResponse(message,status=status.HTTP_200_OK, safe=False)
            else:
                return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST, safe=False)
        except Exception as e:
            message = {"Error": str(e)}
            return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)

class deleteprofile(APIView):
    def delete(self,request,username):
        try:
            customerData.objects.filter(username=username).delete()
            message = {"message":"Profile Deleted Successfully"}
            return JsonResponse(message,status=status.HTTP_204_NO_CONTENT, safe=False)
        except Exception as e:
            message = {"Error": str(e)}
            return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)

class getspecificproduct(APIView):
    def get(self, request, p_id):
        try:
            productdetails= list(category.objects.filter(
                p_id_id= p_id
            ).values())[0]
            productdetails2= list(product.objects.filter(
                p_id= p_id
            ).values())[0]
            productdetails2["c_name"]=productdetails["c_name"]
            x = list(sub_category.objects.filter(
                c_name_id = productdetails["c_name"]
            ).values())[0]
            productdetails2["sub_c_name"]=x["sub_c_name"]
            return JsonResponse(productdetails2, status=status.HTTP_200_OK, safe=False)

        except Exception as e:
            message = {"Error": str(e)}
            return JsonResponse(message, status=status.HTTP_400_BAD_REQUEST, safe=False)